
// Self Invoking function
(function(){
	
	// EmpData Object storing member variable
	var EmpData = {
		fname : "",
		lname : "",
		address : "",
		email : "",
		age : 0,
		phneno : ""
	};
	
	var storeData = {
		saveItem : function(){
			var isCount = localStorage.length;
			var formData = document.getElementsByClassName("form-control");
			EmpData.fname = formData[0].value;
			EmpData.lname = formData[1].value;
			EmpData.address = formData[2].value;
			EmpData.email = formData[3].value;
			EmpData.age = formData[4].value;
			EmpData.phneno = formData[5].value;
			
			// Only valididate the input fields are empty or not
			if(EmpData.fname == null || EmpData.lname == ""){
				//alert("Please Enter First Name");
				return false;
			}
			else if(EmpData.lname == null || EmpData.lname == ""){
				//alert("Please Enter Last Name");
				return false;
			}
			else if(EmpData.address == null || EmpData.address == ""){
				//alert("Please Enter Address");
				return false;
			}
			else if(EmpData.email == null || EmpData.email == ""){
				//alert("Please Enter Email Address");
				return false;
			}
			else if(EmpData.age == null || EmpData.age == ""){
				//alert("Please Enter Age");
				return false;
			}
			else if(EmpData.phneno == null || EmpData.phneno == ""){
				//alert("Please Enter Phone Number");
				return false;
			}				
			// Store data in localStorage
			localStorage.setItem("EmpData_" + isCount, JSON.stringify(EmpData));
			// Page reload
			location.reload();
			
		},
		loadItem : function(){
			var datacount = localStorage.length;
			if (datacount > 0){
				var render = "<table class='table table-bordered'>";
				render += "<tr><th>Sl.No.</th><th>Emp. First Name</th><th>Emp. Last Name</th><th>Emp. Address</th>" + 
                          "<th>Emp. Email</th><th>Emp. Age</th><th>Emp. Phn No.</th></tr>";
						  
                    for (i=0; i < datacount; i++) { 
                        var key = localStorage.key(i); 
                        var EmpData = localStorage.getItem(key); 
                        var data = JSON.parse(EmpData); // Parse JSON data to retrieve the data elements
                        render+="<tr><td>"+Number(i+1)+"</td>";
                        render += "<td>" + data.fname + "</td><td>" + data.lname + "</td>";
                        render += "<td>" + data.address + "</td>";
                        render += "<td>" + data.email + "</td>";
                        render += "<td>" + data.age + "</td>";
						render += "<td>" + data.phneno + "</td>";
                    }
                    render += "</table>";
                    var newTable = document.getElementById("divContainer");
                    newTable.innerHTML = render;
			}
		}
	}
	window.onload = function() {
	storeData.loadItem(); //at first, loading the existing data in localStorage to the front end table 
	var btnsubmit = document.getElementById('btnsubmit');
	btnsubmit.addEventListener('click', storeData.saveItem);// attaching the saveItem function to the Submit button. Onclick of Submit, saveItem() is executed
	};	
})();

// Jquery for Removing the data stored in table
$(function(){
  $("#btnclear").click(function(e){
	  e.preventDefault();
	  localStorage.clear();
	  location.reload();
  });
});